﻿ALTER TABLE fields
ADD COLUMN variety VARCHAR(255),
ADD COLUMN specific_variety VARCHAR(255),
ADD COLUMN rootstock VARCHAR(255),
ADD COLUMN planting_year INTEGER,
ADD COLUMN irrigation_type VARCHAR(255);
