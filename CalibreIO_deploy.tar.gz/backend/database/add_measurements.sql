﻿ALTER TABLE size_controls
ADD COLUMN measurements JSONB;
