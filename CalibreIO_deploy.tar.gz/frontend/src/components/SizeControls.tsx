import { useState, useEffect, useMemo } from 'react';
import api from '../api';
import { Field, SizeControl } from '../types';
import { Plus, Trash2, Save, BarChart3, Settings, TrendingUp, TrendingDown, Minus, X, Edit2 } from 'lucide-react';

export default function SizeControls() {
    const [controls, setControls] = useState<SizeControl[]>([]);
    const [fields, setFields] = useState<Field[]>([]);
    const [loading, setLoading] = useState(true);

    // Field filter & selection
    const [selectedFieldId, setSelectedFieldId] = useState<string>('');

    // Editing state
    const [editingId, setEditingId] = useState<string | null>(null);

    // Configuration
    const [samplesPerZone, setSamplesPerZone] = useState(10);
    const [sampleInput, setSampleInput] = useState('10');
    const [showConfig, setShowConfig] = useState(false);

    // Form State
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [notes, setNotes] = useState('');
    const [zones, setZones] = useState<{ id: string, name: string, values: string[] }[]>([
        { id: '1', name: 'Zona 1', values: Array(10).fill('') }
    ]);

    const fetchData = async () => {
        try {
            setLoading(true);
            const [controlsRes, fieldsRes] = await Promise.all([
                api.get(selectedFieldId ? `/size-controls?field_id=${selectedFieldId}` : '/size-controls'),
                api.get('/fields')
            ]);
            setControls(controlsRes.data);
            setFields(fieldsRes.data);

            // Auto select field if none
            if (!selectedFieldId && fieldsRes.data.length > 0) {
                setSelectedFieldId(fieldsRes.data[0].id);
            }
        } catch (err) {
            console.error('Error fetching data:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [selectedFieldId]);

    const handleSampleSizeCommit = () => {
        const num = Math.min(100, Math.max(1, parseInt(sampleInput) || 1));
        setSamplesPerZone(num);
        setSampleInput(num.toString());

        setZones(prev => prev.map(zone => {
            const current = zone.values;
            let newValues;
            if (current.length < num) {
                newValues = [...current, ...Array(num - current.length).fill('')];
            } else {
                newValues = current.slice(0, num);
            }
            return { ...zone, values: newValues };
        }));
    };

    useEffect(() => {
        setSampleInput(samplesPerZone.toString());
    }, [samplesPerZone]);

    const handleValueChange = (zoneId: string, index: number, value: string) => {
        setZones(prev => prev.map(zone => {
            if (zone.id === zoneId) {
                const newValues = [...zone.values];
                newValues[index] = value;
                return { ...zone, values: newValues };
            }
            return zone;
        }));
    };

    const handleZoneNameChange = (zoneId: string, newName: string) => {
        setZones(prev => prev.map(zone => zone.id === zoneId ? { ...zone, name: newName } : zone));
    };

    const addZone = () => {
        const id = Date.now().toString();
        const num = zones.length + 1;
        setZones(prev => [
            ...prev,
            { id, name: `Zona ${num}`, values: Array(samplesPerZone).fill('') }
        ]);
    };

    const removeZone = (zoneId: string) => {
        if (zones.length > 1) {
            setZones(prev => prev.filter(z => z.id !== zoneId));
        }
    };

    const calculateAverage = (values: string[]) => {
        const nums = values.map(v => parseFloat(v.replace(',', '.'))).filter(n => !isNaN(n) && n > 0);
        if (nums.length === 0) return 0;
        return nums.reduce((a, b) => a + b, 0) / nums.length;
    };

    const currentStats = useMemo(() => {
        const zoneAvgs = zones.map(z => calculateAverage(z.values));
        const validAvgs = zoneAvgs.filter(a => a > 0);

        const totalAvg = validAvgs.length > 0
            ? validAvgs.reduce((a, b) => a + b, 0) / validAvgs.length
            : 0;

        let totalSamples = 0;
        zones.forEach(z => {
            totalSamples += z.values.filter(v => parseFloat(v) > 0).length;
        });

        return { zoneAvgs, totalAvg, totalSamples };
    }, [zones]);

    const currentGrowth = useMemo(() => {
        if (controls.length === 0 || !controls[0].average_size) return 0;
        return currentStats.totalAvg - Number(controls[0].average_size);
    }, [currentStats.totalAvg, controls]);

    const getGrowth = (currentAvg: number, index: number) => {
        const prevItem = controls[index + 1];
        if (!prevItem || !prevItem.average_size) return null;
        return currentAvg - Number(prevItem.average_size);
    };

    const handleSave = async () => {
        if (!selectedFieldId) {
            alert('Tria un camp primer.');
            return;
        }

        const hasData = zones.some(z => z.values.some(v => v !== ''));
        if (!hasData) {
            alert('Si us plau introdueix almenys un valor.');
            return;
        }

        const measurements = zones.map(z => ({
            name: z.name,
            values: z.values.map(v => parseFloat(v.replace(',', '.')) || 0).filter(n => n > 0)
        }));

        const payload = {
            field_id: selectedFieldId,
            user_id: '6d35034c-6f45-4e2c-91c8-e272a65ae0d8', // Temporal hardcode
            date,
            average_size: parseFloat(currentStats.totalAvg.toFixed(2)),
            sample_size: currentStats.totalSamples,
            notes,
            measurements
        };

        try {
            if (editingId) {
                await api.put(`/size-controls/${editingId}`, payload);
                alert('Actualitzat correctament');
            } else {
                await api.post('/size-controls', payload);
                alert('Guardat correctament');
            }

            setEditingId(null);
            setZones([{ id: '1', name: 'Zona 1', values: Array(samplesPerZone).fill('') }]);
            setNotes('');
            fetchData();
        } catch (err) {
            console.error('Error saving control:', err);
            alert('Error en guardar el registre.');
        }
    };

    const handleEdit = (item: SizeControl) => {
        setEditingId(item.id);
        setDate(item.date);
        setNotes(item.notes || '');

        // The backend returns measurements JSON as property or string depending on postgres
        let measureObj = item.measurements;
        if (typeof measureObj === 'string') {
            try {
                measureObj = JSON.parse(measureObj);
            } catch (e) { }
        }

        if (measureObj && Array.isArray(measureObj) && measureObj.length > 0) {
            const newZones = measureObj.map((m: any, idx: number) => ({
                id: Date.now().toString() + idx,
                name: m.name,
                values: [
                    ...m.values.map((v: any) => v.toString()),
                    ...Array(Math.max(0, samplesPerZone - m.values.length)).fill('')
                ]
            }));
            setZones(newZones);
        } else {
            setZones([{ id: '1', name: 'Zona 1', values: Array(samplesPerZone).fill('') }]);
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleCancelEdit = () => {
        setEditingId(null);
        setNotes('');
        setDate(new Date().toISOString().split('T')[0]);
        setZones([{ id: '1', name: 'Zona 1', values: Array(samplesPerZone).fill('') }]);
    };

    const handleDelete = async (id: string) => {
        if (confirm('Segur que vols eliminar aquesta presa de dades?')) {
            try {
                await api.delete(`/size-controls/${id}`);
                fetchData();
            } catch (err) {
                console.error(err);
            }
        }
    };

    if (loading && fields.length === 0) return <div className="p-8 text-center text-gray-500">Carregant mòdul...</div>;

    return (
        <div className="space-y-6 max-w-5xl mx-auto pb-12">

            {/* Field Selector */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                <label className="block text-sm font-bold text-slate-700 mb-2">Camp seleccionat per a prendre calibres:</label>
                {fields.length === 0 ? (
                    <p className="text-red-500 text-sm">No has donat d'alta cap camp encara!</p>
                ) : (
                    <select
                        value={selectedFieldId}
                        onChange={(e) => setSelectedFieldId(e.target.value)}
                        className="w-full md:w-1/2 border border-slate-300 rounded-md p-2 outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 font-medium"
                    >
                        {fields.map(f => (
                            <option key={f.id} value={f.id}>{f.name}</option>
                        ))}
                    </select>
                )}
            </div>

            {selectedFieldId && (
                <div className="space-y-6">
                    {/* Input Section */}
                    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                            <h3 className="font-bold text-slate-700 flex items-center gap-2">
                                <Plus className="w-5 h-5 text-emerald-600" />
                                {editingId ? 'Editar Control Calibres' : 'Nou Control Calibres'}
                            </h3>
                            <div className="flex gap-2 items-center">
                                {editingId && (
                                    <button onClick={handleCancelEdit} className="text-sm text-slate-500 hover:text-slate-800 underline mr-4">
                                        Cancel·lar
                                    </button>
                                )}
                                <button
                                    onClick={() => setShowConfig(!showConfig)}
                                    className={`p-2 rounded-lg transition-colors ${showConfig ? 'bg-emerald-100 text-emerald-700' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-200'}`}
                                >
                                    <Settings className="w-5 h-5" />
                                </button>
                            </div>
                        </div>

                        <div className="p-4 sm:p-6 space-y-6">
                            {/* Config Panel */}
                            {showConfig && (
                                <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 animate-in slide-in-from-top-2 space-y-4">
                                    <div>
                                        <label className="block text-sm font-bold text-emerald-800 mb-2">Fruits per zona</label>
                                        <div className="flex items-center gap-4">
                                            <input
                                                type="number"
                                                min="1"
                                                max="100"
                                                value={sampleInput}
                                                onChange={(e) => setSampleInput(e.target.value)}
                                                onBlur={handleSampleSizeCommit}
                                                onKeyDown={(e) => e.key === 'Enter' && handleSampleSizeCommit()}
                                                className="w-24 px-3 py-2 border border-emerald-300 rounded-lg text-emerald-900 font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                                            />
                                            <span className="text-sm text-emerald-600">fruits per cada zona/bloc</span>
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-center bg-white/50 p-3 rounded-lg">
                                        <span className="text-sm font-medium text-emerald-800">Zones / Blocs de control</span>
                                        <button
                                            onClick={addZone}
                                            className="bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-emerald-700 transition-colors flex items-center gap-2"
                                        >
                                            <Plus className="w-4 h-4" /> Afegir Zona
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Config Summary Quick Access */}
                            {!showConfig && (
                                <div className="flex justify-between items-center bg-slate-50 px-4 py-2 rounded-lg border border-slate-200 text-sm">
                                    <div className="flex items-center gap-2 text-slate-600">
                                        <Settings className="w-4 h-4" />
                                        <span>Configuració actual: <span className="font-bold text-slate-800">{samplesPerZone} mostres</span> x <span className="font-bold text-slate-800">{zones.length} zones</span></span>
                                    </div>
                                    <button onClick={() => setShowConfig(true)} className="text-emerald-600 font-medium hover:underline">
                                        Canviar
                                    </button>
                                </div>
                            )}

                            {/* Date & Note */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">Data</label>
                                    <input
                                        type="date"
                                        value={date}
                                        onChange={(e) => setDate(e.target.value)}
                                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">Notes i Observacions</label>
                                    <input
                                        value={notes}
                                        onChange={(e) => setNotes(e.target.value)}
                                        placeholder="Opcional..."
                                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                                    />
                                </div>
                            </div>

                            {/* Zones Inputs */}
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {zones.map((zone) => {
                                    const avg = calculateAverage(zone.values);
                                    return (
                                        <div key={zone.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 relative group/zone">
                                            <div className="flex justify-between items-center mb-3">
                                                <input
                                                    value={zone.name}
                                                    onChange={(e) => handleZoneNameChange(zone.id, e.target.value)}
                                                    className="font-bold text-sm lg:text-base text-slate-700 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-emerald-500 outline-none w-1/2 transition-colors"
                                                />
                                                <div className="flex items-center gap-2">
                                                    <div className="text-xs sm:text-sm bg-white px-2 py-1 rounded border border-slate-200 shadow-sm">
                                                        Mitjana: <span className="font-bold text-emerald-600">{avg.toFixed(1)}</span> mm
                                                    </div>
                                                    {zones.length > 1 && (
                                                        <button
                                                            onClick={() => removeZone(zone.id)}
                                                            className="text-slate-300 hover:text-red-500 p-1 opacity-100 md:opacity-0 md:group-hover/zone:opacity-100 transition-opacity"
                                                            title="Eliminar Zona"
                                                        >
                                                            <X className="w-4 h-4" />
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
                                                {zone.values.map((val, idx) => (
                                                    <input
                                                        key={`${zone.id}-${idx}`}
                                                        type="text"
                                                        inputMode="decimal"
                                                        placeholder="0"
                                                        value={val}
                                                        onChange={(e) => {
                                                            const v = e.target.value;
                                                            if (/^[0-9.,]*$/.test(v)) {
                                                                handleValueChange(zone.id, idx, v);
                                                            }
                                                        }}
                                                        className="w-full px-1 py-1.5 text-center border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-medium"
                                                    />
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}

                                <button
                                    onClick={addZone}
                                    className="bg-white p-4 rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400 hover:border-emerald-300 hover:text-emerald-600 transition-all min-h-[160px]"
                                >
                                    <Plus className="w-8 h-8 mb-2" />
                                    <span className="font-bold">Afegir Zona / Bloc</span>
                                </button>
                            </div>

                            {/* Summary Bar */}
                            <div className="flex flex-col sm:flex-row justify-between items-center bg-emerald-50 p-4 rounded-xl border border-emerald-100 gap-4 mt-8">
                                <div className="flex items-center gap-4">
                                    <div className="text-center">
                                        <div className="text-xs text-emerald-600 uppercase font-bold tracking-wider">Mitjana Total</div>
                                        <div className="text-3xl font-bold text-emerald-800">
                                            {currentStats.totalAvg > 0 ? currentStats.totalAvg.toFixed(2) : '--'} <span className="text-sm font-normal text-emerald-600">mm</span>
                                        </div>
                                    </div>

                                    {currentStats.totalAvg > 0 && controls.length > 0 && (
                                        <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-bold ${currentGrowth > 0 ? 'bg-emerald-100 text-emerald-700' : currentGrowth < 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                                            {currentGrowth > 0 ? <TrendingUp className="w-4 h-4" /> : currentGrowth < 0 ? <TrendingDown className="w-4 h-4" /> : <Minus className="w-4 h-4" />}
                                            {currentGrowth > 0 ? '+' : ''}{currentGrowth.toFixed(2)} mm
                                        </div>
                                    )}
                                </div>

                                <button
                                    onClick={handleSave}
                                    disabled={currentStats.totalAvg === 0}
                                    className="w-full sm:w-auto flex items-center justify-center gap-2 bg-emerald-600 text-white px-8 py-3 rounded-lg hover:bg-emerald-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed font-bold"
                                >
                                    <Save className="w-5 h-5" />
                                    Guardar
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* History List */}
                    <div>
                        <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                            <BarChart3 className="w-5 h-5 text-slate-400" />
                            Historial de Calibres
                        </h3>

                        {loading ? (
                            <div className="text-center py-12 text-slate-400 animate-pulse">Carregant dades...</div>
                        ) : controls.length === 0 ? (
                            <div className="text-center py-12 text-slate-400 italic bg-white rounded-xl border border-dashed border-slate-300">
                                Encara no hi ha registres de calibres per aquest camp.
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {controls.map((item, idx) => {
                                    const growth = getGrowth(Number(item.average_size) || 0, idx);

                                    let ms = item.measurements;
                                    if (typeof ms === 'string') {
                                        try { ms = JSON.parse(ms); } catch (e) { }
                                    }

                                    return (
                                        <div key={item.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
                                                <div>
                                                    <div className="flex items-center gap-3">
                                                        <div className="font-bold text-slate-800 text-lg">{item.formatted_date || new Date(item.date).toLocaleDateString()}</div>
                                                        <div className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded-full">{item.sample_size} mostres</div>
                                                    </div>
                                                    {item.notes && <div className="text-sm text-slate-500 mt-1">{item.notes}</div>}
                                                </div>

                                                <div className="flex items-center gap-4">
                                                    {item.average_size != null && (
                                                        <div className="text-right">
                                                            <div className="text-2xl font-bold text-emerald-700">{Number(item.average_size).toFixed(2)} mm</div>
                                                            {growth !== null && (
                                                                <div className={`text-xs font-bold flex items-center justify-end gap-1 ${growth > 0 ? 'text-emerald-600' : growth < 0 ? 'text-amber-500' : 'text-slate-400'}`}>
                                                                    {growth > 0 ? <TrendingUp className="w-3 h-3" /> : growth < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                                                                    {growth > 0 ? '+' : ''}{growth.toFixed(2)}
                                                                </div>
                                                            )}
                                                        </div>
                                                    )}
                                                    <button onClick={() => handleEdit(item)} className="text-slate-300 hover:text-blue-500 p-2 hover:bg-blue-50 rounded-lg transition-colors md:opacity-0 md:group-hover:opacity-100" title="Editar">
                                                        <Edit2 className="w-4 h-4" />
                                                    </button>
                                                    <button onClick={() => handleDelete(item.id)} className="text-slate-300 hover:text-red-500 p-2 hover:bg-red-50 rounded-lg transition-colors md:opacity-0 md:group-hover:opacity-100" title="Eliminar">
                                                        <Trash2 className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            </div>

                                            {Array.isArray(ms) && (
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2 pt-3 border-t border-slate-100">
                                                    {ms.map((m: any) => {
                                                        const hasValues = m.values.length > 0;
                                                        const zoneAvg = hasValues
                                                            ? m.values.reduce((a: number, b: number) => a + Number(b), 0) / m.values.length
                                                            : 0;

                                                        return (
                                                            <div key={m.name}>
                                                                <div className="flex justify-between text-xs mb-1">
                                                                    <span className="font-bold text-slate-600">{m.name}</span>
                                                                    <span className="text-slate-400">
                                                                        {hasValues ? `Ø ${zoneAvg.toFixed(1)}` : '-'}
                                                                    </span>
                                                                </div>
                                                                <div className="flex flex-wrap gap-1">
                                                                    {m.values.map((v: any, i: number) => (
                                                                        <span key={i} className="text-[10px] sm:text-xs bg-slate-50 text-slate-500 px-1.5 py-0.5 rounded border border-slate-100">
                                                                            {v}
                                                                        </span>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
